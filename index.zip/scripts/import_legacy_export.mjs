import fs from "node:fs/promises";
import process from "node:process";
import {initializeApp,applicationDefault} from "firebase-admin/app";
import {getFirestore,FieldValue} from "firebase-admin/firestore";

const args=process.argv.slice(2),apply=args.includes("--apply");
const p=args.indexOf("--project"),f=args.indexOf("--file");
const projectId=p>=0?args[p+1]:"",file=f>=0?args[f+1]:"";
if(!projectId||!file){console.error("الاستخدام: node scripts/import_legacy_export.mjs --project PROJECT_ID --file qama-local.json [--apply]");process.exit(2);}
const src=JSON.parse(await fs.readFile(file,"utf8"));
if(src.format!=="qama-legacy-localstorage-v1"||!src.values)throw new Error("BAD_LEGACY_EXPORT");
initializeApp({projectId,credential:applicationDefault()});const db=getFirestore();
const canonical=v=>Array.isArray(v)?v.map(canonical):(v&&typeof v==="object"?Object.fromEntries(Object.keys(v).sort().map(k=>[k,canonical(v[k])])):v);
const equal=(a,b)=>JSON.stringify(canonical(a))===JSON.stringify(canonical(b));
const candidates=[];
for(const [key,raw] of Object.entries(src.values)){
  let value;try{value=JSON.parse(raw);}catch{throw new Error("INVALID_JSON:"+key);}
  if(key.startsWith("qama_month_"))candidates.push({path:"months/"+key.slice(11),data:{data:value,_rev:1,migratedFrom:"legacy-localstorage",migratedAt:FieldValue.serverTimestamp()}});
  else if(key==="qama_permissions")candidates.push({path:"config/permissions",data:{data:value,migratedFrom:"legacy-localstorage",migratedAt:FieldValue.serverTimestamp()}});
  else if(key==="qama_custom_units")candidates.push({path:"config/customUnits",data:{data:value,migratedFrom:"legacy-localstorage",migratedAt:FieldValue.serverTimestamp()}});
}
const create=[],same=[],conflicts=[];
for(const c of candidates){const s=await db.doc(c.path).get();if(!s.exists){create.push(c);continue;}
  const old=s.data(),oldValue=c.path.startsWith("months/")?(old.data||old):(old.data||old),newValue=c.data.data;
  (equal(oldValue,newValue)?same:conflicts).push(c.path);
}
console.log(JSON.stringify({mode:apply?"apply":"plan",source:file,candidates:candidates.length,toCreate:create.map(x=>x.path),alreadyEqual:same,conflicts},null,2));
if(conflicts.length){console.error("توقف: توجد نسخ مختلفة. لم يُكتب شيء؛ راجعها يدوياً ولا تختر نسخة بالتخمين.");process.exit(3);}
if(!apply)process.exit(0);
for(let i=0;i<create.length;i+=450){const b=db.batch();for(const c of create.slice(i,i+450))b.create(db.doc(c.path),c.data);await b.commit();}
console.log(`تم إنشاء ${create.length} مستنداً فقط. لم يُستبدل أو يُحذف أي مستند موجود.`);
