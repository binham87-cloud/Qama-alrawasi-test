import process from "node:process";
import crypto from "node:crypto";
import {initializeApp,applicationDefault} from "firebase-admin/app";
import {getFirestore,FieldValue} from "firebase-admin/firestore";

const apply=process.argv.includes("--apply");
const projectAt=process.argv.indexOf("--project");
const projectId=projectAt>=0?process.argv[projectAt+1]:process.env.GCLOUD_PROJECT;
if(!projectId){console.error("حدد --project PROJECT_ID. الوضع الافتراضي يعرض الخطة فقط.");process.exit(2);}
initializeApp({projectId,credential:applicationDefault()});
const db=getFirestore();
const money=v=>Math.round((Number(v)||0)*100)/100;
const received=x=>{
  const paid=money(x?.paid_amount),rent=money(x?.rent);
  if(x?.partial&&paid>0)return paid;
  return ["collected","paid"].includes(String(x?.status||""))?rent:paid;
};
const id=s=>crypto.createHash("sha256").update(s).digest("hex").slice(0,32);
const badDates=(x,label,out)=>{
  for(const k of ["start_date","end_date","due_date","contract_end"]){
    const v=String(x?.[k]||""); if(/^2013-/.test(v))out.push({label,problem:"year-2013",field:k,value:v});
  }
  if(x?.start_date&&x?.end_date&&x.start_date>x.end_date)out.push({label,problem:"start-after-end",start:x.start_date,end:x.end_date});
};
const months=await db.collection("months").get();
const existingPayments=await db.collection("bankPayments").get();
const existingKeys=new Set(existingPayments.docs.map(d=>`${d.data().monthKey}|${d.data().unitRef}`));
const paymentWrites=[]; const anomalies=[];
for(const md of months.docs){
  const root=md.data()||{},d=root.data||root,monthKey=md.id;
  for(const u of d.units||[])for(const p of u.partitions||[]){
    const ref=`u${u.id}p${p.id}`,label=`${monthKey}:${u.name||u.id}/${p.id}`;badDates(p,label,anomalies);
    const amt=received(p); if(p.collectionMethod!=="bank"||!(amt>0)||existingKeys.has(`${monthKey}|${ref}`))continue;
    const key=`legacy|${monthKey}|${ref}`;
    paymentWrites.push({docId:`legacy_${id(key)}`,data:{idempotencyKey:key,unitRef:ref,unitLabel:`${u.name||u.id} #${p.id}`,tenant:p.tenant||"",unitId:u.id,partId:p.id,monthKey,amount:amt,method:"bank",bankReference:p.bankReference||"LEGACY-MIGRATION",paymentDate:p.collectedAt?.slice?.(0,10)||`${monthKey.slice(0,4)}-${monthKey.slice(5,7)}-01`,status:p.bankDeposited?"approved":"pending",createdBy:p.collectedBy||"legacy",createdAt:p.collectedAt||new Date().toISOString(),approvedBy:p.bankDeposited?"legacy-migration":null,approvedAt:p.bankDeposited?new Date().toISOString():null,cancelledAt:null,cancelReason:null,migratedFrom:"months/"+monthKey}});
  }
  for(const u of d.full||[]){
    const ref=`full${u.id}`,label=`${monthKey}:full/${u.id}`;badDates(u,label,anomalies);
    const amt=received(u); if(u.collectionMethod!=="bank"||!(amt>0)||existingKeys.has(`${monthKey}|${ref}`))continue;
    const key=`legacy|${monthKey}|${ref}`;
    paymentWrites.push({docId:`legacy_${id(key)}`,data:{idempotencyKey:key,unitRef:ref,unitLabel:`شقة ${u.id}`,tenant:u.tenant||"",unitId:u.id,partId:null,monthKey,amount:amt,method:"bank",bankReference:u.bankReference||"LEGACY-MIGRATION",paymentDate:u.collectedAt?.slice?.(0,10)||`${monthKey.slice(0,4)}-${monthKey.slice(5,7)}-01`,status:u.bankDeposited?"approved":"pending",createdBy:u.collectedBy||"legacy",createdAt:u.collectedAt||new Date().toISOString(),approvedBy:u.bankDeposited?"legacy-migration":null,approvedAt:u.bankDeposited?new Date().toISOString():null,cancelledAt:null,cancelReason:null,migratedFrom:"months/"+monthKey}});
  }
}
const balancesSnap=await db.doc("config/balances").get();
const balances=balancesSnap.exists?balancesSnap.data():{};
const ledger=await db.collection("ledger").get();
const net={company:0,revenue:0,installment:0};
for(const d of ledger.docs){const x=d.data();if(net[x.account]!=null)net[x.account]+=x.direction==="credit"?money(x.amount):-money(x.amount);}
const current={company:money(balances.companyBalance),revenue:money(balances.revenueBalance),installment:money(balances.installmentBalance)};
const openings=Object.keys(net).map(account=>({account,amount:money(current[account]-net[account])})).filter(x=>Math.abs(x.amount)>=0.01);
const report={projectId,mode:apply?"apply":"plan",months:months.size,bankPaymentsToCreate:paymentWrites.length,openingEntries:openings,anomalies};
console.log(JSON.stringify(report,null,2));
if(!apply)process.exit(anomalies.length?3:0);
if(anomalies.length){console.error("توقف التطبيق: صحح/اعتمد قائمة التواريخ الشاذة يدوياً أولاً. لم يُكتب شيء.");process.exit(3);}
const marker=db.doc("config/system");
if((await marker.get()).data()?.financialMigrationV11?.completed===true){console.error("الترحيل منفذ مسبقاً.");process.exit(4);}
const writes=[];
for(const p of paymentWrites)writes.push({ref:db.collection("bankPayments").doc(p.docId),data:p.data});
for(const o of openings){const key=`opening-v11|${o.account}`;writes.push({ref:db.collection("ledger").doc(`opening_${id(key)}`),data:{operationId:key,operationType:"opening_balance",account:o.account,direction:o.amount>=0?"credit":"debit",amount:Math.abs(o.amount),balanceBefore:0,balanceAfter:o.amount,monthKey:"opening",sourceCollection:"config",sourceId:"balances",description:"قيد افتتاحي يحافظ على الرصيد القائم",idempotencyKey:key,createdBy:"admin-migration",createdAt:FieldValue.serverTimestamp(),reverseOf:null}});}
for(let i=0;i<writes.length;i+=450){const b=db.batch();for(const w of writes.slice(i,i+450))b.set(w.ref,w.data,{merge:false});await b.commit();}
await marker.set({financialMigrationV11:{completed:true,completedAt:FieldValue.serverTimestamp(),paymentsCreated:paymentWrites.length,openingEntries:openings.length,monthsChecked:months.size}},{merge:true});
console.log("اكتمل الترحيل. مستندات months لم تُعدّل ولم تُحذف.");
