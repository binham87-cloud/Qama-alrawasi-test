import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";

const html = fs.readFileSync(new URL("../index.html", import.meta.url), "utf8");
const rules = fs.readFileSync(new URL("../firestore-v11.rules", import.meta.url), "utf8");
const fn = fs.readFileSync(new URL("../functions/index.mjs", import.meta.url), "utf8");
const cryptoCode = fs.readFileSync(new URL("../functions/pin_crypto.mjs", import.meta.url), "utf8");

test("واجهة الدخول تستخدم PIN وFirebase custom token", () => {
  assert.match(html, /function renderHome\(/);
  assert.match(html, /function pinPress\(/);
  assert.match(html, /httpsCallable\(functions,"pinLogin"\)/);
  assert.match(html, /signInWithCustomToken/);
  assert.doesNotMatch(html, /signInWithEmailAndPassword/);
});

test("لا توجد أرقام PIN ثابتة أو حقول كلمة مرور داخل HTML", () => {
  assert.doesNotMatch(html, /\bpin\s*:\s*["']\d{4}["']/i);
  assert.doesNotMatch(html, /type\s*:\s*["']password["']/i);
});

test("PIN الخام لا يُحفظ في مستند Firebase", () => {
  assert.match(cryptoCode, /pbkdf2Sync/);
  assert.match(cryptoCode, /timingSafeEqual/);
  assert.doesNotMatch(fn, /tx\.set\([\s\S]{0,300}\bpin\s*:/);
});

test("قواعد Firestore تمنع العميل من قراءة مادة PIN", () => {
  assert.match(rules, /match \/authPins\/\{userKey\} \{ allow read, write: if false; \}/);
});

test("فتح شهر موجود لا يعيد بناءه ولا يدمج حذفاً تلقائياً", () => {
  const start = html.indexOf("async function loadMonthOnline");
  const end = html.indexOf("async function saveMonthData", start);
  const block = html.slice(start, end);
  assert.match(block, /if\(snap\.exists\(\)\)/);
  assert.match(block, /memPut\(k,finalData,finalRev\)/);
  assert.doesNotMatch(block, /isOldAutoFilledMonth/);
  assert.doesNotMatch(block, /isBlankMonth\(data\)/);
  assert.doesNotMatch(block, /mergeCustomUnits\(data/);
});

test("الدمج التلقائي للوحدات لا يحذف وحدات موجودة", () => {
  const start = html.indexOf("function mergeCustomUnits");
  const end = html.indexOf("async function loadMonthOnline", start);
  const block = html.slice(start, end);
  assert.doesNotMatch(block, /data\.units\s*=\s*data\.units\.filter/);
  assert.doesNotMatch(block, /data\.full\s*=\s*data\.full\.filter/);
});

test("HTML لا يحتوي بيانات وحدات أو مستخدمين أو أرصدة افتراضية", () => {
  assert.doesNotMatch(html, /\bBASE_UNITS\b|\bBASE_FULL\b|APRIL_MIGRATION/);
  assert.doesNotMatch(html, /S\.user\s*===\s*["'](?:saeed|yahia|nader)["']/);
  assert.match(html, /const USERS=\{\}/);
});

test("الموظف يرسل للاعتماد دائماً ولا يوجد حفظ مباشر", () => {
  assert.match(html, /const needsApproval=!isOwner/);
  assert.doesNotMatch(html, /تم الحفظ مباشرة|صلاحية كاملة \(بدون اعتماد\)|حفظ مباشر/);
});

test("تشغيل البنك يعتمد على bankPayments فقط", () => {
  assert.doesNotMatch(html, /_legacyBank|\.bankDeposited/);
  assert.match(html, /function bankPaymentsFor/);
});
